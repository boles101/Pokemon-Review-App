﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PokemoneReviewApp.Dto;
using PokemoneReviewApp.Interfaces;
using PokemoneReviewApp.Models;
using PokemoneReviewApp.Repositories;

namespace PokemoneReviewApp.Controllers
{
    public class ReviewerController : BaseController
    {
        private readonly IReviewerRepository _reviewerRepository;
        private readonly IMapper _mapper;
        private readonly IReviewRepository _reviewRepository;

        public ReviewerController(IReviewerRepository reviewerRepository, IMapper mapper,
                                  IReviewRepository reviewRepository)
        {
            _reviewerRepository = reviewerRepository;
            _mapper = mapper;
            _reviewRepository = reviewRepository;
        }


        #region GetAllReviewers

        [HttpGet("GetAllReviewers")]
        public IActionResult GetAllReviewers()
        {
            var reviewers = _reviewerRepository.GetReviewers();
            if (!ModelState.IsValid)
                return BadRequest();
            var mappedReviewers = _mapper.Map<List<ReviewerDto>>(reviewers);
            return Ok(mappedReviewers);
        }

        #endregion

        #region GetReviewer

        [HttpGet("GetReviewer")]
        public IActionResult GetReviewer(int id)
        {
            if (!_reviewerRepository.IsReviewerExist(id))
                return NotFound();
            var reviewer = _reviewerRepository.GetReviewer(id);
            if (!ModelState.IsValid)
                return BadRequest();
            var mappedReviwer = _mapper.Map<ReviewerDto>(reviewer);
            return Ok(mappedReviwer);
        }

        #endregion

        #region GetRevieweByReviewers

        [HttpGet("GetRevieweByReviewers")]
        public IActionResult GetRevieweByReviewers(int ReviwerId)
        {
            if (!_reviewerRepository.IsReviewerExist(ReviwerId))
                return NotFound();
            var review = _reviewerRepository.GetReviewsByReviewers(ReviwerId);

            if (!ModelState.IsValid)
                return BadRequest();
            var mappedReview = _mapper.Map<List<ReviewDto>>(review);
            return Ok(mappedReview);
        }

        #endregion

        #region CreateReviewer

        [HttpPost("CreateReviewer")]
        public IActionResult CreateCountry(/*int reviewId,*/ ReviewerDto CreateReviewer)
        {
            if (CreateReviewer == null)
                return BadRequest();
            var Reviewers = _reviewerRepository.GetReviewers()
                      .Where(c => c.Id == CreateReviewer.Id).FirstOrDefault();
            if (Reviewers != null)
            {
                ModelState.AddModelError("", "Reviewer allready Exists");
                return StatusCode(422, ModelState);
            }
            if (!ModelState.IsValid)
                return BadRequest();
            var MappedReviewer = _mapper.Map<Reviewer>(CreateReviewer);
            //MappedReviewer.Reviews = (ICollection<Review>)_reviewRepository.GetReview(reviewId);

            if (!_reviewerRepository.CreateReviewer(/*reviewId,*/ MappedReviewer))
            {
                ModelState.AddModelError("", "something went wrong while saving");
                return StatusCode(500, ModelState);
            }

            return Ok(MappedReviewer);

        }

        #endregion


        #region Update Reviewer

        [HttpPut("Update Reviewer")]
        public IActionResult UpdateReviewer( int ReviewerId, ReviewerDto UpdatedReviewer)
        {
            if (UpdatedReviewer == null)
                return BadRequest();
            if (ReviewerId != UpdatedReviewer.Id)
                return BadRequest();
            if (!_reviewerRepository.IsReviewerExist(ReviewerId))
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();

            var mappedReviewer = _mapper.Map<Reviewer>(UpdatedReviewer);


            if (!_reviewerRepository.UpdateReviewer(mappedReviewer))
            {
                ModelState.AddModelError("", "something went wrong while updating");
                return StatusCode(500, ModelState);
            }
            return Ok(mappedReviewer);
        }

        #endregion

        [HttpDelete("Delete Reviewer")]
        public IActionResult DeleteReviewer(int reviewerId)
        {
            if (!_reviewerRepository.IsReviewerExist(reviewerId))
                return NotFound();
            var Reviewer = _reviewerRepository.GetReviewer(reviewerId);
            if (Reviewer == null)
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();
            _reviewerRepository.DeleteReviewer(Reviewer);
            return Ok("Deleted Successfully");
        }





    }
}
