﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PokemoneReviewApp.Dto;
using PokemoneReviewApp.Interfaces;
using PokemoneReviewApp.Models;
using PokemoneReviewApp.Repositories;
using System.Security.Cryptography.X509Certificates;

namespace PokemoneReviewApp.Controllers
{
    public class ReviewController : BaseController
    {
        private readonly IReviewRepository _reviewRepository;
        private readonly IMapper _mapper;
        private readonly IPokemonRepository _pokemonRepository;
        private readonly IReviewerRepository _reviewerRepository;

        public ReviewController(IReviewRepository reviewRepository,IMapper mapper
                               ,IPokemonRepository pokemonRepository
                               ,IReviewerRepository reviewerRepository)
        {
            _reviewRepository = reviewRepository;
            _mapper = mapper;
            _pokemonRepository = pokemonRepository;
            _reviewerRepository = reviewerRepository;
        }
        [HttpGet("GetAllReviews")]
        public IActionResult GetAllReviews()
        {
            var reviews = _reviewRepository.GetReviews();
            if(!ModelState.IsValid)
                return BadRequest();
            var mappedReviews = _mapper.Map<List<ReviewDto>>(reviews);
            return Ok(mappedReviews);

        }

        [HttpGet("GetReviewById")]
        public IActionResult GetReviewById(int id)
        {
            if(!_reviewRepository.IsReviewExist(id))
                return NotFound();
            var review = _reviewRepository.GetReview(id);
            if(!ModelState.IsValid)
                return BadRequest();
            var mappedReview = _mapper.Map<ReviewDto>(review);
            return Ok(mappedReview);

        }
        [HttpGet("GetReviewByPokemon")]
        public IActionResult GetReviewByPokemon(int Pokemonid)
        {
            var review = _reviewRepository.GetReviewsOfPokemon(Pokemonid);
            if(review == null)
                return NotFound();
            if(!ModelState.IsValid)
                return BadRequest();

            var mappedReview = _mapper.Map<List<ReviewDto>>(review);
            return Ok(mappedReview);

        }

        [HttpPost("Create Review")]
        public IActionResult CreateCountry(int reviewerId,int pokemonId, ReviewDto CreateReview)
        {
            if (CreateReview == null)
                return BadRequest();
            var Reviews = _reviewRepository.GetReviews()
                      .Where(c => c.Title == CreateReview.Title).FirstOrDefault();
            if (Reviews != null)
            {
                ModelState.AddModelError("", "Review allready Exists");
                return StatusCode(422, ModelState);
            }
            if (!ModelState.IsValid)
                return BadRequest();
            var MappedReview = _mapper.Map<Review>(CreateReview);
            MappedReview.Pokemone = _pokemonRepository.GetPokemonById(pokemonId);
            MappedReview.Reviewer = _reviewerRepository.GetReviewer(pokemonId);



            if (!_reviewRepository.CreateReview(reviewerId,pokemonId, MappedReview))
            {
                ModelState.AddModelError("", "something went wrong while saving");
                return StatusCode(500, ModelState);
            }

            return Ok(MappedReview);
        }

        [HttpPut("Update Review")]
        public IActionResult UpdateReview(int reviewId,ReviewDto UpdatedReview)
        {
            if (UpdatedReview == null)
                return BadRequest();
            if (reviewId != UpdatedReview.Id)
                return BadRequest();
            if (!_reviewRepository.IsReviewExist(reviewId))
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();

            var mappedReview = _mapper.Map<Review>(UpdatedReview);


            if (!_reviewRepository.UpdateReview(mappedReview))
            {
                ModelState.AddModelError("", "something went wrong while updating");
                return StatusCode(500, ModelState);
            }
            _mapper.Map<ReviewDto>(mappedReview);
            return Ok(mappedReview);
        }

        [HttpDelete("Delete Review")]
        public IActionResult DeleteReview(int reviewId)
        {
            if (!_reviewRepository.IsReviewExist(reviewId))
                return NotFound();
            var Review = _reviewRepository.GetReview(reviewId);
            if (Review == null)
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();
            _reviewRepository.DeleteReview(Review);
            return Ok("Deleted Successfully");
        }



    }
}
