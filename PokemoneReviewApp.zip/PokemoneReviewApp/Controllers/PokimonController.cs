﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PokemoneReviewApp.Dto;
using PokemoneReviewApp.Interfaces;
using PokemoneReviewApp.Models;
using PokemoneReviewApp.Repositories;

namespace PokemoneReviewApp.Controllers
{

    public class PokimonController : BaseController
    {
        private readonly IPokemonRepository _pokemonRepository;
        private readonly IMapper _mapper;
        private readonly IOwnerRepository _ownerRepository;
        private readonly ICategoryRepository _categoryRepository;

        public PokimonController(IPokemonRepository pokemonRepository,IMapper mapper,
                                 IOwnerRepository ownerRepository,
                                 ICategoryRepository categoryRepository)
        {
            _pokemonRepository = pokemonRepository;
            _mapper = mapper;
            _ownerRepository = ownerRepository;
            _categoryRepository = categoryRepository;
        }


        #region Get All

        [HttpGet("GetAll")]
        public ActionResult<Pokemon> GetPokimone()
        {
            var pokemons = _mapper.Map<List<PokimonDto>>( _pokemonRepository.GetPokemons());

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            return Ok(pokemons);
        }

        #endregion

        #region Get By Id

        [HttpGet("GetById")]
        public ActionResult<Pokemon> GetPokemonById(int id)
        {
            if (!_pokemonRepository.IsPokemonExist(id))
                return NotFound();

            var Pokemon = _pokemonRepository.GetPokemonById(id);

            if (!ModelState.IsValid)
                return BadRequest();

            return Ok(Pokemon);
        }
        #endregion  

        #region Get By Name

        [HttpGet("GetByName")]
        public ActionResult<Pokemon> GetPokemonByName(string name)
        {
            var Pokemon = _pokemonRepository.GetPokemonByName(name);
            if (Pokemon != null)
                return Ok(Pokemon);
            return NotFound();
        }


        #endregion

        #region Get Rating

        [HttpGet("GetRating")]
        public ActionResult<Pokemon> GetPokemonRating(int id)
        {
            if (!_pokemonRepository.IsPokemonExist(id))
                return NotFound();


            var Pokemon = _pokemonRepository.GetPokemonRating(id);
            if (!ModelState.IsValid)
                return BadRequest();

            return Ok(Pokemon);
        }

        #endregion

        #region Create Pokemon 

        [HttpPost("Create Pokemon")]
        public IActionResult CreateCountry(int OwnerId , int CategoryId ,PokimonDto CreatePokemon)
        {
            if (CreatePokemon == null)
                return BadRequest();
            var pokemons = _pokemonRepository.GetPokemons()
                      .Where(c => c.Name == CreatePokemon.Name).FirstOrDefault();
            if (pokemons != null)
            {
                ModelState.AddModelError("", "Pokemon allready Exists");
                return StatusCode(422, ModelState);
            }
            if (!ModelState.IsValid)
                return BadRequest();
            var MappedPokemon = _mapper.Map<Pokemon>(CreatePokemon);

            if (!_pokemonRepository.CreatePokemon(OwnerId,CategoryId,MappedPokemon))
            {
                ModelState.AddModelError("", "something went wrong while saving");
                return StatusCode(500, ModelState);
            }

            return Ok(MappedPokemon);

        }


        #endregion

        #region Update Pokemon
       
        [HttpPut ("Update Pokemon")]
        public IActionResult UpdatePokemon(int OwnerId, int CategoryId,int PokemonId, PokimonDto UpdatedPokemon)
        {
            if (UpdatedPokemon == null)
                return BadRequest();
            if (PokemonId != UpdatedPokemon.Id)
                return BadRequest();
            if (!_pokemonRepository.IsPokemonExist(PokemonId))
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();

            var mappedPokemon = _mapper.Map<Pokemon>(UpdatedPokemon);
            

            if (!_pokemonRepository.UpdatePokemon(OwnerId,CategoryId,mappedPokemon))
            {
                ModelState.AddModelError("", "something went wrong while updating");
                return StatusCode(500, ModelState);
            }
            return Ok(mappedPokemon);
        }

        #endregion

        #region Delete Pokemon

        [HttpDelete("Delete Pokemon ")]
        public IActionResult DeletePokemon(int PokemonId)
        {
            if (!_pokemonRepository.IsPokemonExist(PokemonId))
                return NotFound();
            var Pokemon = _pokemonRepository.GetPokemonById(PokemonId);
            if (Pokemon == null)
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();
            _pokemonRepository.DeletePokemon(Pokemon);
            return Ok("Deleted Successfully");
        }


        #endregion


    }
}
