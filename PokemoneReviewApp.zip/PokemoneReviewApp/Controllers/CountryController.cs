﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PokemoneReviewApp.Dto;
using PokemoneReviewApp.Interfaces;
using PokemoneReviewApp.Models;
using PokemoneReviewApp.Repositories;

namespace PokemoneReviewApp.Controllers
{

    public class CountryController : BaseController
    {
        private readonly ICountryRepository _countryRepository;
        private readonly IMapper _mapper;

        public CountryController(ICountryRepository countryRepository
                                , IMapper mapper)
        {
            _countryRepository = countryRepository;
            _mapper = mapper;
        }

        [HttpGet("GetAllCountries")]
        public IActionResult GetAllCountries()
        {
            var Countries = _countryRepository.GetCountries();
            var mappedCountries = _mapper.Map<List<CountryDto>>(Countries);
            if (!ModelState.IsValid)
                return BadRequest();
            return Ok(mappedCountries);
        }

        [HttpGet("GetCountryById")]
        public IActionResult GetCountry(int id)
        {
            if (!_countryRepository.IsCountryExists(id))
                return NotFound();
            var country = _countryRepository.GetCountry(id);
            if (!ModelState.IsValid)
                return BadRequest();
            var mappedCountry = _mapper.Map<CountryDto>(country);
            return Ok(mappedCountry);
        }


        [HttpGet("GetCountryByOwner")]
        public IActionResult GetCountryByOwner(int ownerId)
        {
            var country = _countryRepository.GetCounrtyByOwner(ownerId);
            if (!ModelState.IsValid)
                return BadRequest();
            if (country == null)
                return NotFound();
            var mappedCountry = _mapper.Map<CountryDto>(country);
            return Ok(mappedCountry);
        }





        [HttpGet("GetOwnersByCountry")]
        public IActionResult GetOwnersByCountry(int countryId)
        {
            if(!_countryRepository.IsCountryExists(countryId))
                return NotFound();
            var owner = _countryRepository.GetOwnersByCountry(countryId);
            if(!ModelState.IsValid)
                return BadRequest();
            var mappedOwner = _mapper.Map<OwnerDto>(owner);

            return Ok(owner); 
        }



        [HttpPost("Create Country")]
        public IActionResult CreateCountry(CountryDto CountryCreates)
        {
            if (CountryCreates == null)
                return BadRequest();
            var category = _countryRepository.GetCountries()
                      .Where(c => c.Name == CountryCreates.Name).FirstOrDefault();
            if (category != null)
            {
                ModelState.AddModelError("", "Country Allready Exists");
                return StatusCode(422, ModelState);
            }
            if (!ModelState.IsValid)
                return BadRequest();
            var MappedCountry = _mapper.Map<Country>(CountryCreates);

            if (!_countryRepository.CreateCountry(MappedCountry))
            {
                ModelState.AddModelError("", "something went wrong while saving");
                return StatusCode(500, ModelState);
            }

            return Ok(MappedCountry);

        }


        [HttpPut("Update Country")]
        public IActionResult UpdateCategory(int CountryId, CountryDto UpdatedCountry)
        {
            if (UpdatedCountry == null)
                return BadRequest();
            if (CountryId != UpdatedCountry.Id)
                return BadRequest();
            if (!_countryRepository.IsCountryExists(CountryId))
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();

            var mappedcountry = _mapper.Map<Country>(UpdatedCountry);

            if (!_countryRepository.UpdateCountry(mappedcountry))
            {
                ModelState.AddModelError("", "something went wrong while updating");
                return StatusCode(500, ModelState);
            }
            return Ok(mappedcountry);
        }

        [HttpDelete("Delete Country ")]
        public IActionResult DeleteCountry(int CountryId)
        {
            if (!_countryRepository.IsCountryExists(CountryId))
                return NotFound();
            var country = _countryRepository.GetCountry(CountryId);
            if (country == null)
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();
            _countryRepository.DeleteCountry(country);
            return Ok("Deleted Successfully");
        }



    }
}
