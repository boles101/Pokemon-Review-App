﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using PokemoneReviewApp.Dto;
using PokemoneReviewApp.Interfaces;
using PokemoneReviewApp.Models;
using PokemoneReviewApp.Repositories;

namespace PokemoneReviewApp.Controllers
{

    public class OwnerController : BaseController
    {
        private readonly IOwnerRepository _ownerRepository;
        private readonly IMapper _mapper;
        private readonly ICountryRepository _countryRepository;

        public OwnerController(IOwnerRepository ownerRepository, IMapper mapper
                              , ICountryRepository countryRepository)
        {
            _ownerRepository = ownerRepository;
            _mapper = mapper;
            _countryRepository = countryRepository;
        }

        [HttpGet("GetAllOwners")]
        public IActionResult GetAllOwners()
        {
            var Owners = _ownerRepository.GetOwners();
            if (!ModelState.IsValid)
                return BadRequest();
            var mappedOwners = _mapper.Map<List<OwnerDto>>(Owners);
            return Ok(mappedOwners);
        }

        [HttpGet("GetOwnerBYId")]
        public IActionResult GetOwner(int ownerId)
        {
            var owner = _ownerRepository.GetOwner(ownerId);
            if (!_ownerRepository.IsOwnerExist(ownerId))
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();
            var mappedOwner = _mapper.Map<OwnerDto>(owner);
            return Ok(mappedOwner);
        }
        [HttpGet("GetOwnerOfPokimon")]
        public IActionResult GetOwnerByPokimonId(int pokimonId)
        {
            var owners = _ownerRepository.GetOwnerOfPokimon(pokimonId);
            if (owners == null)
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();
            var mappedOwner = _mapper.Map<List<OwnerDto>>(owners);

            return Ok(mappedOwner);
        }

        [HttpGet("GetPokimonByOwner")]
        public IActionResult GetPokimonByOwner(int ownerId)
        {
            if (!_ownerRepository.IsOwnerExist(ownerId))
                return NotFound();
            var pokemon = _ownerRepository.GetPokimonByOwner(ownerId);
            if (!ModelState.IsValid && pokemon == null)
                return BadRequest();
            var mappedPokemon = _mapper.Map<List<PokimonDto>>(pokemon);
            return Ok(mappedPokemon);

        }

        #region Create Owner

        [HttpPost("Create Owner")]
        public IActionResult CreateCountry(int countryId , OwnerDto OwnerCreates)
        {
            if (OwnerCreates == null)
                return BadRequest();
            var owners = _ownerRepository.GetOwners()
                      .Where(c => c.FirstName == OwnerCreates.FirstName &&
                             c.LastName == OwnerCreates.LastName)
                      .FirstOrDefault();

            if (owners != null)
            {
                ModelState.AddModelError("", "Owner Allready Exists");
                return StatusCode(422, ModelState);
            }
            if (!ModelState.IsValid)
                return BadRequest();
            var MappedOwner = _mapper.Map<Owner>(OwnerCreates);

            MappedOwner.Country = _countryRepository.GetCountry(countryId);

            if (!_ownerRepository.CreateCategory(MappedOwner))
            {
                ModelState.AddModelError("", "something went wrong while saving");
                return StatusCode(500, ModelState);
            }

            return Ok(MappedOwner); 

        }

        #endregion


        #region Update Owner
        [HttpPut("Update Owner")]
        public IActionResult UpdateOwner(int OwnerId, OwnerDto UpdatedOwner)
        {
            if (UpdatedOwner == null)
                return BadRequest();
            if (OwnerId != UpdatedOwner.Id)
                return BadRequest();
            if (!_ownerRepository.IsOwnerExist(OwnerId))
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();

            var mappedOwner = _mapper.Map<Owner>(UpdatedOwner);

            if (!_ownerRepository.UpdateOwner(mappedOwner))
            {
                ModelState.AddModelError("", "something went wrong while updating");
                return StatusCode(500, ModelState);
            }
            return Ok(mappedOwner);
        }
        #endregion

        #region Delete Owner

        [HttpDelete("Delete Owner ")]
        public IActionResult DeleteOwner(int OwnerId)
        {
            if (!_ownerRepository.IsOwnerExist(OwnerId))
                return NotFound();
            var Owner = _ownerRepository.GetOwner(OwnerId);
            if (Owner == null)
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();
            _ownerRepository.DeleteOwner(Owner);
            return Ok("Deleted Successfully");
        }

        #endregion



    }
}
