﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PokemoneReviewApp.Dto;
using PokemoneReviewApp.Interfaces;
using PokemoneReviewApp.Models;

namespace PokemoneReviewApp.Controllers
{
    public class CategoryController : BaseController
    {
        private readonly ICategoryRepository _categoryRepository;
        private readonly IMapper _mapper;

        public CategoryController(ICategoryRepository categoryRepository,
                                  IMapper mapper
                                 )
        {
            _categoryRepository = categoryRepository;
            _mapper = mapper;
        }



        [HttpGet("Get Categories")]
        public IActionResult GetAllCategories()
        {
            var MappedCategories = _mapper.Map<List<CategoryDto>>
                                          (_categoryRepository.GetCategories());
            if (!ModelState.IsValid)
                return BadRequest();
            return Ok(MappedCategories);

        }



        [HttpGet("Get Category ById")]
        public IActionResult GetCategory(int id)
        {
            if(!_categoryRepository.IsCategoryExist(id))
                return NotFound();
            var Category = _categoryRepository.GetCategory(id);
            var MappedCategory = _mapper.Map<CategoryDto>(Category);
            return Ok(MappedCategory);
        }



        [HttpGet("GetPokimon By Category")]
        public IActionResult GetPokimonByCategory(int categoryId)
        {
            if(!_categoryRepository.IsCategoryExist(categoryId))
                return NotFound();

            var Pokimon = _categoryRepository.GetPokimonByCategory(categoryId);

            ICollection<PokimonDto> mappedPokimon = _mapper.Map<List<PokimonDto>>(Pokimon);

            return Ok(mappedPokimon);
        }





        [HttpPost("Create Category")]
        public IActionResult CreateCategory(CategoryDto categoryCreates)
        {
            if(categoryCreates == null)
                return BadRequest();
            var category = _categoryRepository.GetCategories()
                      .Where(c => c.Name == categoryCreates.Name).FirstOrDefault();
            if (category != null)
            {
                ModelState.AddModelError("", "Category Allready Exists");
                return StatusCode(422, ModelState);
            }
            if(!ModelState.IsValid)
                return BadRequest();
            var MappedCategory = _mapper.Map<Category>(categoryCreates);

            if (!_categoryRepository.CreateCategory(MappedCategory))
            {
                ModelState.AddModelError("", "something went wrong while saving");
                return StatusCode(500, ModelState);
            }

            return Ok(MappedCategory); 
        }



        [HttpPut("Update Category")]
        public IActionResult UpdateCategory(int CategoryId, CategoryDto UpdatedCategory)
        { 
            if(UpdatedCategory == null)
                return BadRequest();
            if (CategoryId != UpdatedCategory.Id)
                return BadRequest();
            if(!_categoryRepository.IsCategoryExist(CategoryId))
                return NotFound();
            if(!ModelState.IsValid)
                return BadRequest();

            var mappedcategory = _mapper.Map<Category>(UpdatedCategory);

            if (!_categoryRepository.UpdateCategory(mappedcategory))
            {
                ModelState.AddModelError("", "something went wrong while updating");
                return StatusCode(500, ModelState);
            }
            return Ok(mappedcategory);
        }

        [HttpDelete("Delete Category ")]
        public IActionResult DeleteCategory(int CategoryId)
        {
            if (!_categoryRepository.IsCategoryExist(CategoryId))
                return NotFound();
            var Category = _categoryRepository.GetCategory(CategoryId);
            if (Category == null)
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();
            _categoryRepository.DeleteCategory(Category);
            return Ok("Deleted Successfully");
        }

        //[HttpDelete("Delete Category ")]
        //public IActionResult DeleteCategory(int CategoryId)
        //{
        //    if (!_categoryRepository.IsCategoryExist(CategoryId))
        //        return NotFound();
        //    if(!_categoryRepository.DeleteCategory(CategoryId))
        //        return BadRequest();
        //    return Ok("delted Successfully");   

        //}







    }





}

