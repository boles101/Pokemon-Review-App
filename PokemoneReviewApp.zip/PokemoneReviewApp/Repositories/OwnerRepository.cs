﻿using PokemoneReviewApp.Data;
using PokemoneReviewApp.Interfaces;
using PokemoneReviewApp.Models;

namespace PokemoneReviewApp.Repositories
{
    public class OwnerRepository : IOwnerRepository
    {
        private readonly PokemonReviewDbContext _context;

        public OwnerRepository(PokemonReviewDbContext context)
        {
            _context = context;
        }

        public bool CreateCategory(Owner owner)
        {
            _context.Add(owner);
            return Save();
        }

        public bool DeleteOwner(Owner owner)
        {
            _context.Owners.Remove(owner);  
            return Save();
        }

        public Owner GetOwner(int ownerId)
        {
            return _context.Owners.Where(x => x.Id == ownerId).FirstOrDefault();
            
        }

        public ICollection<Owner> GetOwnerOfPokimon(int PokimonId)
        {
            return _context.PokemonOwners.Where(x => x.PokemonId == PokimonId)
                                         .Select(x => x.Owner).ToList();      
        }

        public ICollection<Owner> GetOwners()
        {
            return _context.Owners.OrderBy(x => x.Id).ToList();
        }

        public ICollection<Pokemon> GetPokimonByOwner(int OwnerId)
        {
            return _context.PokemonOwners.Where(x => x.OwnerId == OwnerId)
                                         .Select(x=> x.Pokemon).ToList();
        }

        //public ICollection<Pokemon> GetPokimonByOwner(int OwnerId)
        //{
        //    return _context.PokemonOwners.Where(x => x.Owner.Id == OwnerId)
        //                                 .Select(x => x.Pokemon).ToList();
        //}


        public bool IsOwnerExist(int ownerId)
        {
            return _context.Owners.Any(x => x.Id == ownerId);
        }

        public bool Save()
        {
            var save = _context.SaveChanges();  
            return save > 0 ? true : false;
        }

        public bool UpdateOwner(Owner owner)
        {
            _context.Update(owner);
            return Save();
        }
    }
}
