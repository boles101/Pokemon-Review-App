﻿using PokemoneReviewApp.Data;
using PokemoneReviewApp.Interfaces;
using PokemoneReviewApp.Models;
using System.ComponentModel;

namespace PokemoneReviewApp.Repositories
{
    public class ReviewRepository : IReviewRepository
    {
        private readonly PokemonReviewDbContext _context;

        public ReviewRepository(PokemonReviewDbContext context)
        {
            _context = context;
        }

        public bool CreateReview(int reviewerId, int pokemonId, Review review)
        {
            _context.Reviews.Add(review);
            return Save();

        }

        public bool DeleteReview(Review Review)
        {
            _context.Remove(Review);
            return Save();
        }

        public Review GetReview(int ReviewId)
        {
            return _context.Reviews.Where(x => x.Id == ReviewId).FirstOrDefault();
         
        }

        public ICollection<Review> GetReviews()
        {
            return _context.Reviews.ToList();
        }

        public ICollection<Review> GetReviewsOfPokemon(int pokemonId)
        {
            return _context.Reviews.Where(x => x.Pokemone.Id == pokemonId).ToList();
        }

        public bool IsReviewExist(int reviewId)
        {
            return _context.Reviews.Any(x => x.Id == reviewId);
        }

        public bool Save()
        {
            var Save = _context.SaveChanges();  
            return Save > 0 ? true : false;
        }

        public bool UpdateReview(Review review)
        {
            _context.Update(review);
            return Save();
        }
    }
}
