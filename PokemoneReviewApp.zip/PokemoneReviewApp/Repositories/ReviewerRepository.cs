﻿using Microsoft.EntityFrameworkCore;
using PokemoneReviewApp.Data;
using PokemoneReviewApp.Interfaces;
using PokemoneReviewApp.Models;

namespace PokemoneReviewApp.Repositories
{
    public class ReviewerRepository : IReviewerRepository
    {
        private readonly PokemonReviewDbContext _context;

        public ReviewerRepository(PokemonReviewDbContext context)
        {
            _context = context;
        }
        public ICollection<Review> GetReviewsByReviewers(int ReviewerId)
        {
            return _context.Reviews.Where(x => x.Reviewer.Id == ReviewerId).ToList();
            
        }

        public Reviewer GetReviewer(int id)
        {
            return _context.Reviewers.Include(x => x.Reviews).Where(x => x.Id == id).FirstOrDefault();
        }

        public ICollection<Reviewer> GetReviewers()
        {
            return _context.Reviewers.Include(r => r.Reviews).ToList();
        }

        public bool IsReviewerExist(int id)
        {
            return _context.Reviewers.Any( x => x.Id == id);
        }

        public bool CreateReviewer(/*int review,*/ Reviewer reviewer)
        {
            _context.Add(reviewer);
            return Save();
        }

        public bool Save()
        {
            var save = _context.SaveChanges();
            return save > 0 ? true : false;
        }

        public bool UpdateReviewer(Reviewer reviewer)
        {
            _context.Update(reviewer);
            return Save();
        }

        public bool DeleteReviewer(Reviewer reviewer)
        {
            _context.Remove(reviewer);
            return Save();
        }
    }
}
