﻿using PokemoneReviewApp.Data;
using PokemoneReviewApp.Dto;
using PokemoneReviewApp.Interfaces;
using PokemoneReviewApp.Models;

namespace PokemoneReviewApp.Repositories
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly PokemonReviewDbContext _context;
        private readonly IPokemonRepository _pokemonRepository;

        public CategoryRepository(PokemonReviewDbContext context
                                 ,IPokemonRepository pokemonRepository)
        {
            _context = context;
            _pokemonRepository = pokemonRepository;
        }


        public bool CreateCategory(Category category)
        {
            _context.Categories.Add(category);
            return Save();

        }

        ////Deleting within the Repository !!
        //public bool DeleteCategory(int categoryId)
        //{
        //    var category = _context.Categories.FirstOrDefault(c => c.Id == categoryId);
        //    if (category is null)
        //        throw new Exception("The Categoy is not found");
        //    _context.Remove(category);
        //    return Save();
        //}



        //Deleting within the controller !!


        public bool DeleteCategory(Category category)
        {
            _context.Categories.Remove(category);
            return Save();
        }

        public ICollection<Category> GetCategories()
        {
            return _context.Categories.OrderBy( c => c.Id ).ToList();
            
        }

        public Category GetCategory(int id)
        {
            return _context.Categories.Where( c => c.Id == id).FirstOrDefault();
            
        }

        public ICollection<Pokemon> GetPokimonByCategory(int categoryId)
        {
            //ICollection<Pokemon> AllPokemons = _pokemonRepository.GetPokemons();
            //var PokimonesInCategory = AllPokemons.Where(c => c.Id == categoryId).ToList();
            //return PokimonesInCategory ;


            return _context.PokemonCategories.Where(e => e.CategoryId == categoryId)
                                             .Select(e => e.Pokemon)
                                             .ToList();
        }

        public bool IsCategoryExist(int categoryId)
        {
         // return _context.Categories.Where(c => c.Id == categoryId).Any();

            return _context.Categories.Any((c => c.Id == categoryId));

        }

        public bool Save()
        {
            var save = _context.SaveChanges();
            return save > 0 ? true : false;
        }

        public bool UpdateCategory(Category category)
        {
            _context.Update(category);

            return Save();
        }
    }
}
