﻿using PokemoneReviewApp.Data;
using PokemoneReviewApp.Interfaces;
using PokemoneReviewApp.Models;
using System.Xml.Linq;

namespace PokemoneReviewApp.Repositories
{
    public class PokemonRepository:IPokemonRepository

    {
        private readonly PokemonReviewDbContext _context;

        public PokemonRepository(PokemonReviewDbContext context)
        {
            _context = context;
        }


        public ICollection<Pokemon> GetPokemons()
        {
            return _context.Pokemon.OrderBy(p => p.Id).ToList();
        }

        public  Pokemon GetPokemonById(int id)
        {
            return _context.Pokemon.Where(x => x.Id == id).FirstOrDefault();
                
        }

        public Pokemon GetPokemonByName(string name)
        {
            return _context.Pokemon.Where(n => n.Name == name).FirstOrDefault();
        }

        public decimal GetPokemonRating(int id)
        {
            var reviews = _context.Reviews.Where(p => p.Pokemone.Id == id);

            if(reviews == null || reviews.Count() <= 0 )
                return 0;

            return ((decimal)reviews.Sum(r => r.Rating) / reviews.Count());
        } 



        public bool IsPokemonExist(int id)
        {
            return  _context.Pokemon.Any(x => x.Id == id);
        }

        public bool CreatePokemon(int OwnerId, int CategoryId, Pokemon pokemon)
        {
            var PokemonOwnerEntity = _context.Owners.Where( x => x.Id == OwnerId).FirstOrDefault();
            var Category = _context.Categories.Where( x => x.Id == CategoryId).FirstOrDefault();

            var PokemonOwner = new PokemonOwner()
            {
                Owner = PokemonOwnerEntity,
                Pokemon = pokemon,
            };
            _context.Add(PokemonOwner);

            var pokemonCategory = new PokemonCategory()
            {
                Category = Category,
                Pokemon = pokemon
            };
            _context.Add(pokemonCategory);

            _context.Add(pokemon);

            return Save();
        }

        public bool Save()
        {
            var save = _context.SaveChanges();
            return save > 0 ? true : false;
        }

        public bool UpdatePokemon(int OwnerId, int CategoryId, Pokemon pokemon)
        {
            _context.Update(pokemon);
            return Save();
        }

        public bool DeletePokemon(Pokemon pokemon)
        {
              _context.Remove(pokemon);
            return Save();
        }
    }
}
