﻿using PokemoneReviewApp.Data;
using PokemoneReviewApp.Interfaces;
using PokemoneReviewApp.Models;

namespace PokemoneReviewApp.Repositories
{
    public class CountryRepository : ICountryRepository
    {
        private readonly PokemonReviewDbContext _context;

        public CountryRepository(PokemonReviewDbContext context)
        {
            _context = context;
        }

        public bool CreateCountry(Country country)
        {
            _context.Add(country);
            return Save();
            
        }

        public bool DeleteCountry(Country country)
        {
            _context.Remove(country);
            return Save();

        }

        public Country GetCounrtyByOwner(int ownerId)
        {
            return _context.Owners.Where(x => x.Id == ownerId)
                                  .Select(x => x.Country).FirstOrDefault();
        }

        public ICollection<Country> GetCountries()
        {
            return _context.Countries.ToList();
        }

        public Country GetCountry(int id)
        {
           return _context.Countries.Where( x=> x.Id == id ).FirstOrDefault();
        }

        public ICollection<Owner> GetOwnersByCountry(int countryId)
        {
            return _context.Owners.Where(x => x.Country.Id == countryId).ToList();
        }

        public bool IsCountryExists(int id)         
        {
            return _context.Countries.Any(x => x.Id == id);
        }

        public bool Save()
        {
            var save = _context.SaveChanges();
            return save > 0 ? true : false;
        }

        public bool UpdateCountry(Country country)
        {
            _context.Update(country);
            return Save();
        }
    }
}
