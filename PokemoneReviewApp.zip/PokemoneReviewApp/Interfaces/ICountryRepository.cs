﻿using PokemoneReviewApp.Models;

namespace PokemoneReviewApp.Interfaces
{
    public interface ICountryRepository
    {
       ICollection<Country> GetCountries();
       Country GetCountry(int id);
        Country GetCounrtyByOwner(int ownerId);
        ICollection<Owner>GetOwnersByCountry(int countryId);
        bool IsCountryExists(int id);

        bool CreateCountry(Country country);
        bool UpdateCountry(Country country);
        bool DeleteCountry(Country country);
        
        public bool Save();



    }
}
