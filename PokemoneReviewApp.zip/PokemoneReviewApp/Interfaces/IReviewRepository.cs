﻿using PokemoneReviewApp.Models;

namespace PokemoneReviewApp.Interfaces
{
    public interface IReviewRepository
    {
        ICollection<Review>GetReviews();
        Review GetReview(int ReviewId);
        ICollection<Review> GetReviewsOfPokemon(int pokemonId);
        bool IsReviewExist(int reviewId);
        bool CreateReview(int ReviewerId,int pokemonId, Review review);
        bool UpdateReview(Review review);
        bool DeleteReview(Review Review);
        bool Save();

    }
}
