﻿using PokemoneReviewApp.Controllers;
using PokemoneReviewApp.Models;

namespace PokemoneReviewApp.Interfaces
{
    public interface IOwnerRepository
    {
        ICollection<Owner> GetOwners();
        Owner GetOwner(int ownerId);
        ICollection<Owner> GetOwnerOfPokimon(int PokimonId);
        ICollection<Pokemon> GetPokimonByOwner(int OwnerId);
        bool IsOwnerExist(int ownerId);
        bool CreateCategory(Owner owner);
        bool UpdateOwner(Owner owner);   
        bool DeleteOwner(Owner owner);
        public bool Save();


    }
}
