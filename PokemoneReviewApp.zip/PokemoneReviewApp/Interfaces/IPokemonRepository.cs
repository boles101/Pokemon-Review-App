﻿using PokemoneReviewApp.Models;

namespace PokemoneReviewApp.Interfaces
{
    public interface IPokemonRepository
    {
        ICollection<Pokemon> GetPokemons();
        Pokemon GetPokemonById(int id);
        Pokemon GetPokemonByName(string name);
        decimal GetPokemonRating(int id);
        bool IsPokemonExist(int id);
        bool CreatePokemon (int OwnerId , int CategoryId, Pokemon pokemon);
        bool UpdatePokemon(int OwnerId, int CategoryId, Pokemon pokemon);
        bool DeletePokemon(Pokemon pokemon);
        bool Save();




    }
}
