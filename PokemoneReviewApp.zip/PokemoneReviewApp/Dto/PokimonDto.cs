﻿namespace PokemoneReviewApp.Dto
{
    public class PokimonDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime BirthDate { get; set; }
    }
}
