﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Validations;
using PokemoneReviewApp.Interfaces;
using PokemoneReviewApp.Repositories;
using PokemonReviewApp;

namespace PokemoneReviewApp.Extensions
{
    public static class ApplicationServiceExtension
    {
        public static IServiceCollection AddServices(this IServiceCollection Services)
        {
            Services.AddControllers();
            Services.AddTransient<Seed>();
            Services.AddScoped<IPokemonRepository, PokemonRepository>();
            Services.AddScoped<ICategoryRepository, CategoryRepository>();
            Services.AddScoped<ICountryRepository, CountryRepository>();
            Services.AddScoped<IOwnerRepository, OwnerRepository>();
            Services.AddScoped<IReviewRepository, ReviewRepository>();
            Services.AddScoped<IReviewerRepository, ReviewerRepository>();
            Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

            return Services;

        }
    }
}
