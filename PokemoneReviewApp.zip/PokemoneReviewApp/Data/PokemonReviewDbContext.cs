﻿using Microsoft.EntityFrameworkCore;
using PokemoneReviewApp.Models;
using System.Reflection;

namespace PokemoneReviewApp.Data
{
    public class PokemonReviewDbContext : DbContext
    {

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());

            modelBuilder.Entity<PokemonCategory>()
                .HasKey(pk => new {pk.CategoryId,pk.PokemonId });

            modelBuilder.Entity<PokemonCategory>()
                .HasOne(p => p.Pokemon)
                .WithMany(pk => pk.pokemoneCategories)
                .HasForeignKey(p => p.PokemonId);

            modelBuilder.Entity<PokemonCategory>()
                .HasOne(p => p.Category)
                .WithMany(pk => pk.PokemoneCategories)
                .HasForeignKey(p => p.CategoryId);

                        //PokemonOwner table

            modelBuilder.Entity<PokemonOwner>() 
                .HasKey(pk => new { pk.PokemonId, pk.OwnerId});

            modelBuilder.Entity<PokemonOwner>()
                .HasOne(p => p.Pokemon)
                .WithMany(pk => pk.PokemoneOwner)
                .HasForeignKey(p => p.PokemonId);

            modelBuilder.Entity<PokemonOwner>()
                .HasOne(p => p.Owner)
                .WithMany(pk => pk.PokemoneOwners)
                .HasForeignKey(p => p.OwnerId);

        }

        public PokemonReviewDbContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Country> Countries{ get; set; }
        public DbSet<Owner> Owners{ get; set; }
        public DbSet<Pokemon> Pokemon{ get; set; }
        public DbSet<PokemonCategory>PokemonCategories  { get; set; }
        public DbSet<PokemonOwner>PokemonOwners{ get; set; }
        public DbSet<Reviewer> Reviewers { get; set; }
        public DbSet<Review>Reviews { get; set; }

    }
}
